import streamlit as st
import os
import cv2
import torch
import numpy as np
from pathlib import Path
from PIL import Image

# ── Imports del Ecosistema de Inferencia ─────────────────────────────
from ultralytics import YOLO
from ultralytics.utils.ops import scale_boxes
from ultralytics.utils.nms import non_max_suppression
from ultralytics.engine.results import Results
import openvino as ov

st.set_page_config(page_title="Local AI people counter v3", layout="wide")

# ════════════════════════════════════════════════════════════════════
# 1. TEXTOS BILINGÜES E INTERFAZ
# ════════════════════════════════════════════════════════════════════
idioma = st.sidebar.selectbox("Idioma / Language", ["Español", "English"])

texts = {
    "Español": {
        "titulo": "Contador de personas",
        "config_ia": "Configuración de IA",
        "selector_precision": "Selecciona el Nivel de Precisión:",
        "ajuste_a": "Ajuste A: Modelo Medium (NPU)",
        "ajuste_b": "Ajuste B: Modelo Large (GPU)",
        "modo_actual": "Modo actual",
        "equilibrio": "Modelo Medium + NPU (Equilibrio)",
        "potencia": "Modelo Large + GPU Arc (Máxima potencia)",
        "cargando_export": "Exportando arquitectura para Intel... (Solo una vez)",
        "cargando_compile": "Inyectando grafo neuronal en el silicio...",
        "sube_foto": "Sube tu fotografía",
        "analizando": "Analizando con precisión quirúrgica...",
        "detectadas": "Personas Detectadas",
        "config_aplicada": "Telemetría de Hardware",
        "hw_usado": "Hardware utilizado",
    },
    "English": {
        "titulo": "People Counter",
        "config_ia": "AI Configuration",
        "selector_precision": "Select Precision Level:",
        "ajuste_a": "Setting A: Medium Model (NPU)",
        "ajuste_b": "Setting B: Large Model (GPU)",
        "modo_actual": "Current mode",
        "equilibrio": "Medium Model + NPU (Balance)",
        "potencia": "Large Model + GPU Arc (Maximum Power)",
        "cargando_export": "Exporting architecture for Intel... (First time only)",
        "cargando_compile": "Injecting neural graph into silicon...",
        "sube_foto": "Upload your photo",
        "analizando": "Analyzing with surgical precision...",
        "detectadas": "People Detected",
        "config_aplicada": "Hardware Telemetry",
        "hw_usado": "Target hardware used",
    }
}
t = texts[idioma]

st.sidebar.markdown("""
    <div style="display:flex;justify-content:center;gap:10px; margin-bottom:15px;width:100%;">
        <div style="width:36px;height:36px;background:#F25022;border-radius:50%;"></div>
        <div style="width:36px;height:36px;background:#7FBA00;border-radius:50%;"></div>
        <div style="width:36px;height:36px;background:#00A4EF;border-radius:50%;"></div>
        <div style="width:36px;height:36px;background:#FFB900;border-radius:50%;"></div>
    </div>
""", unsafe_allow_html=True)

st.sidebar.title(t["config_ia"])
modo = st.sidebar.radio(t["selector_precision"], (t["ajuste_a"], t["ajuste_b"]))

if "Medium" in modo:
    nombre_modelo   = "yolo11m"
    dispositivo_ov  = "NPU"
    img_size        = 640
    descripcion_modo = t["equilibrio"]
else:
    nombre_modelo   = "yolo11l"
    dispositivo_ov  = "GPU"
    img_size        = 1440
    descripcion_modo = t["potencia"]

carpeta_ov = f"{nombre_modelo}_{img_size}_openvino_model"
clave_estado = f"compiled_{nombre_modelo}_{img_size}_{dispositivo_ov}"

# ════════════════════════════════════════════════════════════════════
# 2. MOTORES CORE: EXPORTACIÓN Y COMPILACIÓN
# ════════════════════════════════════════════════════════════════════
def exportar_si_necesario(nombre, carpeta, size):
    if not Path(carpeta).exists():
        with st.spinner(t["cargando_export"]):
            modelo_pt = YOLO(f"{nombre}.pt")
            modelo_pt.export(format="openvino", imgsz=size, half=True, dynamic=False)
            origen = Path(f"{nombre}_openvino_model")
            if origen.exists() and not Path(carpeta).exists():
                origen.rename(carpeta)

@st.cache_resource(show_spinner=False)
def compilar_modelo_ov(carpeta, dispositivo, _clave):
    core = ov.Core()
    if dispositivo not in core.available_devices:
        dispositivo = "CPU"
    
    xml_path = str(next(Path(carpeta).glob("*.xml")))
    with st.spinner(t["cargando_compile"]):
        modelo_ir = core.read_model(xml_path)
        
        config = {}
        if dispositivo == "NPU":
            config = {"NPU_COMPILATION_MODE_PARAMS": "compute-layers-with-higher-precision=Sqrt,Power,ReduceMean,Add_RMSNorm"}
        elif dispositivo == "GPU":
            config = {"PERFORMANCE_HINT": "THROUGHPUT"}

        compiled = core.compile_model(modelo_ir, device_name=dispositivo, config=config)
    return compiled, dispositivo

# ════════════════════════════════════════════════════════════════════
# 3. RESTAURACIÓN DE PRECISIÓN: PIPELINE NATIVO ULTRALYTICS
# ════════════════════════════════════════════════════════════════════
def preprocesar_precision(imagen_pil, size):
    img_np = np.array(imagen_pil)
    shape = img_np.shape[:2]  
    
    r = min(size / shape[0], size / shape[1])
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = size - new_unpad[0], size - new_unpad[1]
    dw, dh = dw / 2, dh / 2  
    
    if shape[::-1] != new_unpad:
        img_np = cv2.resize(img_np, new_unpad, interpolation=cv2.INTER_LINEAR)
        
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    img_padded = cv2.copyMakeBorder(img_np, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(114, 114, 114))
    
    tensor = img_padded.transpose(2, 0, 1)[np.newaxis, ...]
    tensor = np.ascontiguousarray(tensor, dtype=np.float32) / 255.0
    return tensor, shape

# ════════════════════════════════════════════════════════════════════
# 4. FLUJO PRINCIPAL
# ════════════════════════════════════════════════════════════════════
st.title(t["titulo"])
st.info(f"**{t['modo_actual']}:** {descripcion_modo}")

exportar_si_necesario(nombre_modelo, carpeta_ov, img_size)

try:
    compiled_model, dispositivo_efectivo = compilar_modelo_ov(carpeta_ov, dispositivo_ov, _clave=clave_estado)
except Exception as e:
    st.error(f"Error nativo de compilación: {e}")
    compiled_model = None
    dispositivo_efectivo = "ERROR_FALLBACK"

try:
    # Solución al bug visual de "N, P, U" en la interfaz
    devs = compiled_model.get_property("EXECUTION_DEVICES")
    dispositivo_real = ", ".join(devs) if isinstance(devs, (list, tuple)) else str(devs)
except Exception:
    dispositivo_real = dispositivo_efectivo

archivo = st.file_uploader(t["sube_foto"], type=["jpg", "png", "jpeg"])

if archivo and compiled_model is not None:
    imagen_pil = Image.open(archivo).convert("RGB")

    with st.spinner(t["analizando"]):
        tensor, orig_shape = preprocesar_precision(imagen_pil, img_size)

        infer_req = compiled_model.create_infer_request()
        infer_req.infer({0: tensor})
        output_raw = infer_req.get_output_tensor(0).data

        preds = torch.from_numpy(output_raw)
        dets = non_max_suppression(preds, conf_thres=0.12, iou_thres=0.40, classes=[0])[0]

        if len(dets):
            dets[:, :4] = scale_boxes((img_size, img_size), dets[:, :4], orig_shape)
        
        img_bgr = cv2.cvtColor(np.array(imagen_pil), cv2.COLOR_RGB2BGR)
        res = Results(orig_img=img_bgr, path="", names={0: 'persona'}, boxes=dets)
        
        imagen_resultado = Image.fromarray(res.plot()[..., ::-1])
        total = len(dets)

    # Render de Interfaz Limpia (Estilo Dashboard)
    col1, col2 = st.columns([2, 1])
    with col1:
        st.image(imagen_resultado, use_container_width=True)
    with col2:
        st.metric(label=t["detectadas"], value=total)
        st.write(f"**{t['config_aplicada']}:**")
        st.write(f"- {t['hw_usado']}: `{dispositivo_real}`")
        st.write(f"- Arquitectura: `{nombre_modelo}`")
        st.write(f"- Render visual: `Ultralytics Nativo`")