====================================================================
PEOPLE COUNTER - QUICK START GUIDE
====================================================================

This package contains the application optimized to run artificial intelligence 100% LOCALLY, leveraging the integrated hardware (NPU and Intel Arc GPU).

PREREQUISITES:
-----------------
1. Windows 11.
2. Python must be installed (Recommended version: 3.12.9).
   * Note: When installing Python, be sure to check the box that says:
     “Add Python to PATH” or “Add Python to environment variables.”

URL: https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe

3. Have the Visual C++ package installed

URL: https://aka.ms/vc14/vc_redist.x86.exe

HOW TO RUN THE APPLICATION:
---------------------------
1. Extract the entire contents of this ZIP file to any folder on your computer. (Important: It must be a local folder, not one hosted on OneDrive.)
2. DOUBLE-CLICK the “Start_App.bat” file.
3. The first time you run it, the system will take a couple of minutes because it will automatically download and 
   configure the necessary libraries in a secure environment.
4. Once it’s finished, your web browser will open automatically with the application ready to use.
5. The next few times you open it, it will launch immediately (in less than 5 seconds).

PERFORMANCE NOTES (INTEL CORE ULTRA HARDWARE):
------------------------------------------------
* Setting A (NPU): Ideal for minimal battery consumption and continuous streaming.
* Setting B (GPU): Maximum power and resolution (1440px), excellent for compact crowds.
* If the specific hardware system fails or cannot find the drivers, the app features smart protection that automatically switches to the CPU to avoid interrupting the stream.



====================================================================
CONTADOR DE PERSONAS - MANUAL RÁPIDO
====================================================================

Este paquete contiene la aplicación optimizada para correr Inteligencia Artificial de forma 100% LOCAL, aprovechando el hardware integrado (NPU e Intel Arc GPU).

REQUISITOS PREVIOS:
-----------------
1. Windows 11.
2. Tener Python instalado (Versiones sugeridas: 3.12.9).
   * Nota: Al instalar Python, recuerda marcar la casilla abajo que dice:
     "Add Python to PATH" o "Añadir Python a las variables de entorno".

URL: https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe

3. Tener instalado el paquete de Visual C++

URL: https://aka.ms/vc14/vc_redist.x86.exe

CÓMO EJECUTAR LA APLICACIÓN:
---------------------------
1. Descomprime este archivo ZIP por completo en cualquier carpeta de tu ordenador. (Importante sea una carpeta local y no una alojada en OneDrive)
2. Haz DOBLE CLIC sobre el archivo "Start_App.bat".
3. La primera vez, el sistema tardará un par de minutos porque descargará y 
   configurará de forma automática las librerías necesarias en un entorno seguro.
4. Una vez termine, se abrirá automáticamente tu navegador web con la aplicación lista.
5. Las siguientes veces que lo abras, arrancará de forma inmediata (en menos de 5 segundos).

NOTAS DE RENDIMIENTO (HARDWARE INTEL CORE ULTRA):
------------------------------------------------
* Ajuste A (NPU): Ideal para un consumo mínimo de batería y flujos continuos.
* Ajuste B (GPU): Máxima potencia y resolución (1440px), excelente para multitudes compactas.
* Si el sistema de hardware específico falla o no encuentra los drivers, la aplicación cuenta con una protección inteligente que conmuta automáticamente a la CPU para no interrumpir el flujo.
