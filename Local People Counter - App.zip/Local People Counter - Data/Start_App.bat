@echo off
title Lanzador Directo - Contador de Personas IA
color 0A

echo ====================================================================
echo   🚀 ARRANCANDO EN TU ENTORNO GLOBAL (PYTHON 3.14)
echo ====================================================================
echo.
echo Usando la configuracion global donde OpenVINO y tus drivers estan listos.
echo.

pip install openvino ultralytics streamlit opencv-python-headless torch numpy Pillow
python -m streamlit run app.py

pause