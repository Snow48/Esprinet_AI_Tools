@echo off
color 0A
echo Iniciando Newsletter Analyzer...
echo Por favor, espere mientras la IA procesa la bandeja de entrada.

cd /d %~dp0
py main.py

echo.
echo ===================================================
echo Tarea finalizada. Esta ventana se cerrara sola.
echo ===================================================
timeout /t 10 >nul