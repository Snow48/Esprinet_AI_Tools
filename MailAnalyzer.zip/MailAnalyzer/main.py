import imapclient
import email
from email.header import decode_header
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib
from ollama import Client
from datetime import datetime
import json
import sys
import logging
from pathlib import Path
import re
import urllib.parse
import hashlib
import html

class NewsletterAnalyzer:
    def __init__(self, config_path="config/settings.json"):
        self.config_path = config_path
        self.config = self.load_config()
        self.setup_logging()
        
        # =====================================================================
        # CONFIGURACIÓN DEL PERFIL 
        # =====================================================================
        self.USER_ROLE = "Business Developer especializado en ecosistemas de silicio (x86, NPUs, AI PCs), hardware B2B, servicios cloud y canal de distribución."
        
        self.HIGH_VALUE_TOPICS = """
        - REGLA DE ORO: Descuentos, ofertas, "Early Bird", "%", "gratis", "free" en tecnología B2B son PRIORIDAD MÁXIMA (Score 9-10).
        - Oportunidades de negocio, estado del canal B2B, alianzas estratégicas o movimientos de competidores.
        - Lanzamientos de hardware, benchmarks, adopción de NPUs y Edge AI.
        - Eventos, summits y webinars del sector tecnológico.
        """
        
        self.DISCARD_TOPICS = """
        - Ofertas B2C puras o sectores NO tecnológicos (ropa, viajes, supermercados, sorteos/sweepstakes genéricos).
        - Notificaciones administrativas (entornos inactivos, cierres de cuenta, términos de servicio).
        """
        # =====================================================================
        
        self.SECURITY_PATTERNS = [
            r'new login', r'unusual activity', r'security alert', r'password reset',
            r'alerta de seguridad', r'nuevo inicio de sesión', r'actividad inusual',
            r'vulnerability', r'breach', r'cuenta bloqueada', r'verify your account'
        ]
        
        self.SPAM_PATTERNS = [
            r'\bzara\b', r'\bfashion\b', r'\bmoda\b', r'\bropa\b', r'\bzapatos\b', r'\blifestyle\b',
            r'\bsupermercado\b', r'\bvuelos baratos\b', r'\bhoteles\b', r'booking\.com',
            r'\bcosmética\b', r'\bperfume\b'  
        ]
        
        # ESCUDO ADMINISTRATIVO: Evita que un aviso de cuenta gratuita pase como "promo"
        self.ADMIN_PATTERNS = [
            r'\binactiv[oa]\b', r'\binactive\b', r'\bdeactivat', r'\bdesactivad',
            r'\bsuspend', r'\baction required\b', r'\bacción requerida\b', r'\bpolicy update\b',
            r'\bterms of service\b', r'\bshutting down\b', r'\bsweepstakes\b'
        ]

        self.PROMO_PATTERNS = [
            r'\b\d+\s*%\s*(?:off|descuento|dto|rebaja|menos)\b', r'-\s*\d+\s*%',
            r'\bahorra\b', r'\bsave\b', r'\bdescuent[oa]s?\b', r'\bdiscounts?\b', 
            r'\brebajas?\b', r'\bofertas?\b', r'\boffers?\b', r'\bpromoci[oó]n(?:es)?\b', 
            r'\bpromos?\b', r'\bprecio especial\b', r'\bspecial price\b', r'\bprice drop\b',
            r'\bgratis\b', r'\bfree\b', r'\bregalos?\b', r'\bgiveaways?\b', 
            r'\bprueba gratuita\b', r'\bfree trial\b', r'\b0\s*[€$]\b', r'\bcoste cero\b',
            r'\bsin coste\b', r'\bno cost\b', r'\bcomplimentary\b', r'\bfreemium\b',
            r'\bearly bird\b', r'\bexclusiv[oa]s?\b', r'\bexclusives?\b',
            r'\bcup[oó]n(?:es)?\b', r'\bcoupons?\b', r'\bvouchers?\b', r'\bc[oó]digo de descuento\b', 
            r'\bpromo code\b', r'\bcr[eé]ditos?\b', r'\bcredits?\b', r'\bcashback\b', 
            r'\bpartner program\b', r'\bbundles?\b', r'\bpaquetes?\b',
            r'\búltima oportunidad\b', r'\blast chance\b', r'\btiempo limitado\b', 
            r'\blimited time\b', r'\bflash sale\b', r'\bventas? flash\b', r'\bliquidaci[oó]n\b'
        ]

        self.processed_hashes = {}
    
    def load_config(self):
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"Error: No se encontró el archivo {self.config_path}")
            sys.exit(1)
    
    def setup_logging(self):
        log_file = self.config['output']['log_file']
        Path(log_file).parent.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file, encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

    def _generate_hash(self, subject, sender):
        clean_sub = re.sub(r'(?i)(re:|fwd:|fw:|\[.*?\])', '', subject).strip().lower()
        clean_sender = sender.split('<')[0].strip().lower()
        hash_input = f"{clean_sub}||{clean_sender}"
        return hashlib.md5(hash_input.encode('utf-8')).hexdigest()
    
    def _clean_text(self, text):
        text = re.sub(r'<img[^>]+alt=["\']([^"\']+)["\'][^>]*>', r'  ', text, flags=re.IGNORECASE)
        clean = re.sub(r'<[^>]+>', ' ', text)
        clean = html.unescape(clean)
        return re.sub(r'\s+', ' ', clean).strip()

    def _calculate_reading_time(self, body):
        words = len(body.split())
        minutes = max(1, round(words / 200))
        return minutes

    def get_unread_emails(self):
        server = None
        try:
            self.logger.info("Conectando a Gmail...")
            config = self.config['email']
            server = imapclient.IMAPClient(config['imap_server'], ssl=True, port=config['imap_port'])
            server.login(config['gmail_user'], config['gmail_password'])
            
            server.select_folder(config['folder_name'])
            unread_ids = server.search(['UNSEEN'])
            
            if not unread_ids:
                self.logger.info("Bandeja limpia. No hay emails sin leer.")
                return []
            
            emails_data = []
            for uid in unread_ids:
                try:
                    raw_email = server.fetch([uid], ['RFC822'])[uid][b'RFC822']
                    email_msg = email.message_from_bytes(raw_email)
                    
                    subject_header = decode_header(email_msg['Subject'])[0]
                    subject = subject_header[0]
                    if isinstance(subject, bytes):
                        subject = subject.decode(subject_header[1] or 'utf-8', errors='ignore')
                    
                    from_addr = email_msg['From']
                    body = ""
                    
                    if email_msg.is_multipart():
                        for part in email_msg.walk():
                            if part.get_content_type() == "text/plain":
                                body = part.get_payload(decode=True).decode('utf-8', errors='ignore')
                                break
                            elif part.get_content_type() == "text/html" and not body:
                                body = part.get_payload(decode=True).decode('utf-8', errors='ignore')
                    else:
                        body = email_msg.get_payload(decode=True).decode('utf-8', errors='ignore')
                    
                    msg_id = email_msg.get('Message-ID', '').strip('<>')
                    clean_body = self._clean_text(body)
                    max_length = self.config['ai']['max_email_length']
                    
                    emails_data.append({
                        'uid': uid,
                        'subject': subject,
                        'from': from_addr,
                        'body': clean_body[:max_length],
                        'full_body_length': len(clean_body),
                        'message_id': msg_id
                    })
                except Exception as e:
                    self.logger.error(f"Error procesando email específico: {e}")
            
            if self.config['execution']['mark_as_read'] and unread_ids:
                server.set_flags(unread_ids, [b'\\Seen'])
            
            return emails_data
            
        except Exception as e:
            self.logger.error(f"Error crítico conectando a Gmail: {e}")
            return []
        finally:
            if server:
                try:
                    server.logout()
                except:
                    pass

    def analyze_email(self, subject, body, email_from):
        combined_text = (subject + " " + body).lower()
        
        # 1. Alertas de Seguridad
        for pattern in self.SECURITY_PATTERNS:
            if re.search(pattern, combined_text, re.IGNORECASE):
                return {
                    'status': 'SECURITY',
                    'score': 10,
                    'category': 'SECURITY',
                    'title': f"ALERTA CRÍTICA: {subject[:40]}",
                    'key_points': ['Posible brecha o aviso de seguridad.', 'Se requiere intervención manual inmediata.'],
                    'method': 'regex_security'
                }

        # 2. Descarte Spam (Sectores no tech)
        for pattern in self.SPAM_PATTERNS:
            if re.search(pattern, combined_text, re.IGNORECASE):
                return {'status': 'IGNORE', 'score': 0, 'method': 'regex_spam_filter'}
        
        # 3. Detectar si es un aviso administrativo/legal
        is_admin = False
        for pattern in self.ADMIN_PATTERNS:
            if re.search(pattern, combined_text, re.IGNORECASE):
                is_admin = True
                self.logger.info(f"   [!] Aviso administrativo detectado, cancelando override de promo.")
                break

        # 4. CARRIL RÁPIDO: Promociones (Solo si NO es un aviso administrativo)
        has_promo = False
        promo_match = ""
        if not is_admin:
            for pattern in self.PROMO_PATTERNS:
                match = re.search(pattern, combined_text, re.IGNORECASE)
                if match:
                    has_promo = True
                    promo_match = match.group()
                    self.logger.info(f"   [!] Promo/Oferta detectada por Python: '{promo_match}'")
                    break

        return self._deep_analyze_with_phi3(subject, body, has_promo, promo_match, is_admin)
    
    def _deep_analyze_with_phi3(self, subject, body, has_promo, promo_match, is_admin):
        
        promo_instruction = ""
        if has_promo:
            promo_instruction = f"\n¡ATENCIÓN! PYTHON HA DETECTADO LA OFERTA '{promo_match}'. PON STATUS: RELEVANT Y CATEGORY: PROMOS & EVENTS.\n"
        if is_admin:
            promo_instruction = "\n¡ATENCIÓN! ESTE ES UN CORREO ADMINISTRATIVO O DE DESACTIVACIÓN. DEBES PONERLE SCORE BAJO (0-4) E IGNORARLO.\n"

        prompt = f"""Instrucciones estrictas para clasificar este correo.
ROLE: {self.USER_ROLE}
{promo_instruction}

REGLAS DE EVALUACIÓN:
{self.HIGH_VALUE_TOPICS}

REGLAS DE DESCARTE:
{self.DISCARD_TOPICS}

ASUNTO: {subject}
CONTENIDO: {body[:1000]}...

Responde EXACTAMENTE en este formato. 
IMPORTANTE: Responde en ESPAÑOL NEUTRO PERFECTO. NO inventes palabras como 'inactivismo' o 'desconto'.

STATUS: [Escribe RELEVANT o IGNORE]
SCORE: [Número del 0 al 10]
CATEGORY: [Elige una: BUSINESS & SALES | PROMOS & EVENTS | HARDWARE & AI | SECURITY | CLOUD | OTHER]
TITLE: [Un título descriptivo en ESPAÑOL CLARO, max 8 palabras]
KEY_POINTS: [Dato clave 1 | Dato clave 2]"""
        
        try:
            config = self.config['ai']
            client = Client(host=config['ollama_host'])
            response = client.generate(
                model=config['model'],
                prompt=prompt,
                stream=False
            )
            
            parsed = self._parse_phi3_response(response['response'].strip())
            
            # SALVAVIDAS PYTHON
            if has_promo and not is_admin:
                parsed['status'] = 'RELEVANT'
                parsed['score'] = max(parsed['score'], 9)
                if parsed['category'] in ['OTHER', 'IGNORE', 'SECURITY']:
                    parsed['category'] = 'PROMOS & EVENTS'
                parsed['method'] = f'phi3_override_promo_{promo_match.replace(" ", "_")}'
            elif is_admin:
                parsed['status'] = 'IGNORE'
                parsed['score'] = min(parsed['score'], 4)
                parsed['method'] = 'admin_override'
            else:
                parsed['method'] = 'phi3_strict_analysis'
                if parsed['score'] < 7 and parsed['status'] != 'SECURITY':
                    parsed['status'] = 'IGNORE'
                
            return parsed
            
        except Exception as e:
            self.logger.error(f"Error con IA: {e}")
            return {'status': 'IGNORE', 'score': 0, 'method': 'error_fallback'}
    
    def _parse_phi3_response(self, response_text):
        result = {
            'status': 'IGNORE',
            'score': 0,
            'category': 'OTHER',
            'title': 'Análisis Comercial / Promoción',
            'key_points': ['Revisar detalles en el correo original.']
        }
        
        clean_text = response_text.replace('**', '').replace('*', '').replace('#', '')
        
        for line in clean_text.split('\n'):
            line = line.strip().upper()
            if line.startswith('STATUS:'):
                if 'RELEVANT' in line:
                    result['status'] = 'RELEVANT'
                elif 'IGNORE' in line:
                    result['status'] = 'IGNORE'
            elif line.startswith('SCORE:'):
                try:
                    result['score'] = int(re.search(r'\d+', line).group())
                except:
                    pass
            elif line.startswith('CATEGORY:'):
                try:
                    result['category'] = line.split(':', 1)[1].strip()
                except:
                    pass
            elif line.startswith('TITLE:'):
                try:
                    original_line = [l for l in clean_text.split('\n') if l.strip().upper().startswith('TITLE:')][0]
                    result['title'] = original_line.split(':', 1)[1].strip()[:80]
                except:
                    pass
            elif line.startswith('KEY_POINTS:'):
                try:
                    original_line = [l for l in clean_text.split('\n') if l.strip().upper().startswith('KEY_POINTS:')][0]
                    points = original_line.split(':', 1)[1].split('|')
                    valid_points = [p.strip() for p in points if len(p.strip()) > 3]
                    if valid_points:
                        result['key_points'] = valid_points[:2]
                except:
                    pass
                
        return result

    def _generate_global_tldr(self, relevant_emails):
        if not relevant_emails:
            return ""
            
        categories = list(set([e['category'] for e in relevant_emails]))
        cats_str = ", ".join(categories)
        
        prompt = f"""Completa la siguiente frase de forma natural basándote en estas categorías: {cats_str}

Frase a completar: "El resumen de hoy incluye correos sobre..."

Responde SOLO con la frase completada, sin añadir nada más. NUNCA INVENTES NOTICIAS."""

        try:
            config = self.config['ai']
            client = Client(host=config['ollama_host'])
            response = client.generate(
                model=config['model'],
                prompt=prompt,
                stream=False
            )
            
            clean_response = response['response'].strip().replace('"', '').replace('\n', ' ')
            
            if len(clean_response) > 120 or "amenaza" in clean_response.lower() or "aviso" in clean_response.lower() or "ecuador" in clean_response.lower() or "petróleo" in clean_response.lower():
                return f"El resumen de hoy abarca alertas y oportunidades filtradas en áreas clave como: {cats_str}."
                
            return clean_response
        except:
            return f"Reporte automático generado con {len(relevant_emails)} correos relevantes."
    
    def send_email_summary(self, relevant_emails, tldr):
        if not relevant_emails or not self.config['output']['send_email_summary']:
            self.logger.info("Proceso terminado. No hay contenido de valor comercial o técnico hoy.")
            return False
        
        try:
            html = self._generate_html_summary(relevant_emails, tldr)
            sender = self.config['email']['gmail_user']
            recipient = self.config['output']['summary_recipient'] or sender
            
            msg = MIMEMultipart('alternative')
            msg['Subject'] = f"Intel Briefing // Tech & Market {datetime.now().strftime('%d.%m')}"
            msg['From'] = sender
            msg['To'] = recipient
            
            msg.attach(MIMEText(html, 'html', 'utf-8'))
            
            smtp_server = smtplib.SMTP_SSL('smtp.gmail.com', 465, timeout=10)
            smtp_server.login(sender, self.config['email']['gmail_password'])
            smtp_server.send_message(msg)
            smtp_server.quit()
            
            self.logger.info(f"Reporte estratégico enviado con éxito.")
            return True
            
        except Exception as e:
            self.logger.error(f"Error enviando email: {e}")
            return False
    
    def _generate_html_summary(self, relevant_emails, tldr):
        categorized_emails = {}
        for email in relevant_emails:
            cat = email['category']
            if cat not in categorized_emails:
                categorized_emails[cat] = []
            categorized_emails[cat].append(email)

        html = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {{ font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; background-color: #050505; margin: 0; padding: 20px; color: #e2e8f0; }}
        .container {{ max-width: 650px; margin: 0 auto; background-color: #0a0a0a; border: 1px solid #1e293b; }}
        .header {{ padding: 40px 30px; border-bottom: 1px solid #1e293b; text-align: center; background: linear-gradient(180deg, #0f172a 0%, #0a0a0a 100%); }}
        .header h1 {{ margin: 0; font-size: 20px; font-weight: 300; letter-spacing: 4px; color: #ffffff; text-transform: uppercase; }}
        .tldr-box {{ margin: 30px; padding: 20px; background-color: #0f172a; border-left: 3px solid #38bdf8; font-size: 14px; line-height: 1.6; color: #bae6fd; font-style: italic; text-align: center; }}
        .category-header {{ margin: 30px 30px 10px; font-size: 11px; text-transform: uppercase; letter-spacing: 2px; color: #64748b; border-bottom: 1px solid #1e293b; padding-bottom: 5px; }}
        .email-block {{ padding: 20px 30px; transition: background 0.2s; }}
        .email-block:hover {{ background-color: #111827; }}
        .email-block.security {{ border-left: 3px solid #ef4444; background-color: #1a0f0f; }}
        .meta-row {{ display: flex; flex-wrap: wrap; gap: 10px; align-items: center; margin-bottom: 12px; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; }}
        .badge {{ padding: 3px 8px; border-radius: 2px; font-weight: 600; }}
        .badge-score {{ background-color: #0ea5e9; color: #ffffff; }}
        .badge-sec {{ background-color: #ef4444; color: #ffffff; }}
        .badge-time {{ border: 1px solid #334155; color: #94a3b8; }}
        .badge-dup {{ background-color: #475569; color: #ffffff; }}
        .title {{ margin: 0 0 12px 0; font-size: 16px; font-weight: 400; color: #f8fafc; line-height: 1.4; }}
        .points {{ margin: 0 0 15px 0; padding-left: 0; list-style-type: none; }}
        .points li {{ position: relative; padding-left: 15px; margin-bottom: 8px; color: #94a3b8; font-size: 13px; line-height: 1.5; }}
        .points li::before {{ content: "—"; position: absolute; left: 0; color: #38bdf8; font-weight: bold; }}
        .security .points li::before {{ color: #ef4444; }}
        .btn {{ display: inline-block; padding: 8px 16px; color: #cbd5e1; text-decoration: none; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; border: 1px solid #334155; transition: all 0.2s; }}
        .btn:hover {{ border-color: #38bdf8; color: #38bdf8; }}
        .footer {{ padding: 40px; text-align: center; color: #475569; font-size: 10px; text-transform: uppercase; letter-spacing: 2px; border-top: 1px solid #1e293b; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>NEWSLETTER RESUMEN</h1>
        </div>
        
        {f'<div class="tldr-box">{tldr}</div>' if tldr else ''}
"""
        for category, emails in categorized_emails.items():
            html += f'<div class="category-header">:: {category} ::</div>'
            
            for item in emails:
                gmail_link = f"https://mail.google.com/mail/u/0/#search/rfc822msgid:{urllib.parse.quote(item['message_id'])}"
                is_security = item.get('status') == 'SECURITY'
                
                block_class = "email-block security" if is_security else "email-block"
                score_badge = "badge-sec" if is_security else "badge-score"
                dup_badge = f'<span class="badge badge-dup">Repetido x{item["count"]}</span>' if item['count'] > 1 else ""
                
                html += f"""
                <div class="{block_class}">
                    <div class="meta-row">
                        <span class="badge {score_badge}">Score: {item['score']}</span>
                        <span class="badge badge-time">⏱️ {item['reading_time']} min</span>
                        {dup_badge}
                    </div>
                    <h2 class="title">{item['title']}</h2>
                    <ul class="points">
"""
                for point in item['key_points']:
                    html += f"                        <li>{point}</li>\n"
                    
                html += f"""
                    </ul>
                    <a href="{gmail_link}" class="btn">Desplegar Origen</a>
                </div>
"""
        
        html += """
        <div class="footer">
            Protocolo de Filtrado Analítico Activo.
        </div>
    </div>
</body>
</html>
"""
        return html
    
    def run(self):
        self.logger.info("Iniciando escaneo de bandeja...")
        emails = self.get_unread_emails()
        
        if not emails:
            return []
        
        relevant_emails = []
        
        for i, email_data in enumerate(emails, 1):
            email_hash = self._generate_hash(email_data['subject'], email_data['from'])
            
            existing = next((item for item in relevant_emails if item.get('hash') == email_hash), None)
            if existing:
                existing['count'] += 1
                self.logger.info(f"   [!] DUPLICADO OMITIDO: {email_data['subject'][:40]}")
                continue
                
            analysis = self.analyze_email(
                email_data['subject'], 
                email_data['body'],
                email_data['from']
            )
            
            if analysis['status'] in ['RELEVANT', 'SECURITY'] and analysis['score'] >= 7:
                relevant_emails.append({
                    'hash': email_hash,
                    'count': 1,
                    'title': analysis.get('title', email_data['subject']),
                    'from': email_data['from'],
                    'score': analysis['score'],
                    'category': analysis.get('category', 'OTHER'),
                    'key_points': analysis.get('key_points', []),
                    'message_id': email_data['message_id'],
                    'status': analysis['status'],
                    'reading_time': self._calculate_reading_time(email_data['body'])
                })
                self.logger.info(f"   [+] EXTRAÍDO: {analysis['score']}/10 - {email_data['subject'][:40]}")
            else:
                self.logger.info(f"   [-] IGNORADO - {email_data['subject'][:40]}")
        
        if relevant_emails:
            tldr = self._generate_global_tldr(relevant_emails)
            self.send_email_summary(relevant_emails, tldr)
            
        return relevant_emails

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Tech & Business Newsletter Analyzer")
    parser.add_argument('--config', default='config/settings.json', help='Ruta al archivo config.json')
    args = parser.parse_args()
    
    analyzer = NewsletterAnalyzer(args.config)
    analyzer.run()

if __name__ == "__main__":
    main()