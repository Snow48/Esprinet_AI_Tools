@echo off
chcp 65001 >nul
color 0B
echo ======================================================================
echo          CONFIGURACION DE AUTOMATIZACION - NEWSLETTER ANALYZER
echo ======================================================================
echo.
echo Esto configurara Windows para ejecutar el script de resumen:
echo  - Todos los Viernes a las 10:00 AM.
echo  - Si el PC esta apagado a esa hora, se ejecutara al encenderlo.
echo.
echo Pulse cualquier tecla para instalar o cierre la ventana para cancelar.
pause >nul

:: Obtener la ruta exacta donde esta la carpeta actualmente
set "SCRIPT_DIR=%~dp0"
set "BAT_PATH=%SCRIPT_DIR%run_analyzer.bat"

:: Comando de PowerShell que crea la tarea programada. 
:: Incluye configuraciones para que funcione incluso si es un portatil usando bateria.
powershell -Command "$Action = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument '/c \"\"%BAT_PATH%\"\"'; $Trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Friday -At 9:00am; $Settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries; Register-ScheduledTask -TaskName 'NewsletterAnalyzer_Auto' -Action $Action -Trigger $Trigger -Settings $Settings -Description 'Analisis automatico de newsletters de los viernes' -Force"

echo.
echo ======================================================================
echo [EXITO] Automatizacion configurada correctamente.
echo Ya puedes cerrar esta ventana. El sistema hara el resto cada viernes.
echo ======================================================================
pause >nul