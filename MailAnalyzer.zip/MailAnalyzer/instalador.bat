@echo off
setlocal
echo ===================================================
echo INICIANDO INSTALACION Y CONFIGURACION
echo ===================================================

:: 1. Instalar librerías de Python necesarias
echo Instalando dependencias de Python...
pip install imapclient ollama

:: 2. Verificar/Instalar Ollama
echo Verificando instalacion de Ollama...
where ollama >nul 2>nul
if %errorlevel% neq 0 (
    echo Ollama no detectado. Por favor, descargalo e instalalo desde https://ollama.com/
    pause
    exit
)

:: 3. Descargar el modelo phi3
echo Descargando/Verificando el modelo phi3 (esto puede tardar)...
ollama pull phi3

:: 4. Ejecutar el script principal
echo.
echo Todo listo. Ejecutando analizador...
python main.py

pause